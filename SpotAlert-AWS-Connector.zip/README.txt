SpotAlert AWS Connector Setup Guide
-----------------------------------

1. Upload all files to your AWS EC2 or Elastic Beanstalk server.
2. Rename `.env.example` to `.env` and fill in your AWS keys and email addresses.
3. Install dependencies:
   npm install
4. Start the API:
   npm start
5. Your detection endpoint will run on:
   http://localhost:8080/detect
6. To connect with your SpotAlert dashboard:
   POST form data with field "frame" (image file) to /detect.
7. If the person is unknown, an alert email is sent with a presigned S3 link.
