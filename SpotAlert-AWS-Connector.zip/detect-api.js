import express from "express";
import multer from "multer";
import fs from "fs";
import dotenv from "dotenv";
import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { RekognitionClient, SearchFacesByImageCommand } from "@aws-sdk/client-rekognition";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

dotenv.config();
const app = express();
const upload = multer({ dest: "uploads/" });

const region = process.env.AWS_REGION || "us-east-1";
const s3 = new S3Client({ region });
const rekog = new RekognitionClient({ region });
const ses = new SESClient({ region });

async function uploadToS3(filePath, key) {
  const fileData = fs.readFileSync(filePath);
  await s3.send(new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    Body: fileData,
    ContentType: "image/jpeg"
  }));
  return key;
}

async function presignS3(key) {
  const cmd = new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key });
  return getSignedUrl(s3, cmd, { expiresIn: 3600 });
}

async function sendAlertEmail(imageUrl) {
  const html = `<div style="font-family:Arial;color:#111">
    <h2>⚠️ SpotAlert — Unknown Person Detected</h2>
    <p>Time: ${new Date().toLocaleString()}</p>
    <p><a href="${imageUrl}" target="_blank">Open snapshot</a></p>
    <img src="${imageUrl}" alt="Snapshot" style="max-width:520px;border-radius:8px;margin-top:10px"/>
    <p style="font-size:12px;color:#777;margin-top:20px">This alert was sent by SpotAlert via AWS SES.</p>
  </div>`;

  const cmd = new SendEmailCommand({
    Destination: { ToAddresses: [process.env.SES_TO_EMAIL] },
    Source: process.env.SES_FROM_EMAIL,
    Message: { Subject: { Data: process.env.ALERT_SUBJECT }, Body: { Html: { Data: html } } }
  });

  await ses.send(cmd);
}

app.post("/detect", upload.single("frame"), async (req, res) => {
  try {
    const localFile = req.file.path;
    const key = `frames/${Date.now()}_${req.file.originalname}`;
    await uploadToS3(localFile, key);
    const imgData = fs.readFileSync(localFile);

    const rekogRes = await rekog.send(new SearchFacesByImageCommand({
      CollectionId: process.env.REKOG_COLLECTION_ID,
      Image: { Bytes: imgData },
      FaceMatchThreshold: Number(process.env.MATCH_THRESHOLD) || 92,
      MaxFaces: 1
    }));

    const match = rekogRes.FaceMatches?.[0];
    if (match && match.Similarity >= (process.env.MATCH_THRESHOLD || 92)) {
      res.json({ status: "known", similarity: match.Similarity.toFixed(1), message: "✅ Known person detected." });
    } else {
      const url = await presignS3(key);
      await sendAlertEmail(url);
      res.json({ status: "unknown", message: "🚨 Unknown person detected — alert email sent.", snapshot: url });
    }

    fs.unlinkSync(localFile);
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: "Detection failed", details: err.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`✅ SpotAlert Detection API running at http://localhost:${PORT}`));
