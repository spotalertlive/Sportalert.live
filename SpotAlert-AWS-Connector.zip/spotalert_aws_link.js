// SpotAlert AWS Link helper for manual Rekognition testing
// Usage:
// node spotalert_aws_link.js index ./path/to/image.jpg person-id
// node spotalert_aws_link.js detect ./path/to/image.jpg

import fs from "fs";
import dotenv from "dotenv";
import { RekognitionClient, IndexFacesCommand, SearchFacesByImageCommand } from "@aws-sdk/client-rekognition";

dotenv.config();
const region = process.env.AWS_REGION || "us-east-1";
const rekog = new RekognitionClient({ region });

const [,, mode, filePath, id] = process.argv;
if (!mode || !filePath) {
  console.log("Usage: node spotalert_aws_link.js [index|detect] path/to/image.jpg [person-id]");
  process.exit(1);
}
const bytes = fs.readFileSync(filePath);

(async () => {
  if (mode === "index") {
    const cmd = new IndexFacesCommand({
      CollectionId: process.env.REKOG_COLLECTION_ID,
      Image: { Bytes: bytes },
      ExternalImageId: id || `person-${Date.now()}`
    });
    const res = await rekog.send(cmd);
    console.log("Indexed:", res);
  } else if (mode === "detect") {
    const cmd = new SearchFacesByImageCommand({
      CollectionId: process.env.REKOG_COLLECTION_ID,
      Image: { Bytes: bytes },
      FaceMatchThreshold: Number(process.env.MATCH_THRESHOLD) || 92
    });
    const res = await rekog.send(cmd);
    console.log("Detection result:", res);
  }
})();